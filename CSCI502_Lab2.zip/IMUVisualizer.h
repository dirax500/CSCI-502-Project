#ifndef IMU_VISUALIZER_H
#define IMU_VISUALIZER_H

/**
 * @file IMUVisualizer.h
 * @brief Real-time 3D orientation visualization using OpenGL/FreeGLUT.
 *
 * Renders a 3D cube whose orientation is driven by a quaternion from the
 * Madgwick AHRS filter. This class encapsulates all OpenGL rendering logic,
 * providing a clean interface for the main application to update the
 * displayed orientation.
 *
 * Dependencies: FreeGLUT, OpenGL, GLU
 * Install: sudo apt install -y freeglut3-dev mesa-utils
 */

#include "MadgwickFilter.h"
#include <array>

namespace viz {

class IMUVisualizer {
public:
    IMUVisualizer();
    ~IMUVisualizer() = default;

    /**
     * @brief Initialize the GLUT window and OpenGL state.
     * @param argc, argv  Command-line args forwarded to glutInit.
     * @param width, height  Initial window dimensions.
     * @param title  Window title string.
     */
    void init(int& argc, char** argv,
              int width = 900, int height = 600,
              const char* title = "IMU 3D Orientation Viewer");

    /// Set the orientation quaternion to display.
    void setQuaternion(const imu::Quaternion& q);

    /// Get the current quaternion being displayed.
    imu::Quaternion getQuaternion() const;

    /// Request a redraw of the scene.
    void requestRedraw();

    /**
     * @brief Enter the GLUT main loop (blocking).
     * Call this after all setup is complete.
     */
    void run();

    // --- Static GLUT callbacks (delegate to singleton instance) ---
    static void displayCallback();
    static void reshapeCallback(int w, int h);
    static void keyboardCallback(unsigned char key, int x, int y);
    static void idleCallback();

private:
    void display();
    void reshape(int w, int h);

    /// Convert quaternion to OpenGL 4x4 column-major rotation matrix.
    static std::array<float, 16> quatToMatrix(const imu::Quaternion& q);

    /// Draw world axes (RGB = XYZ).
    void drawAxes(float length = 1.2f);

    /// Draw a wireframe cube.
    void drawCubeWire(float size = 1.0f);

    /// Draw a solid cube with subtle color.
    void drawCubeSolid(float size = 1.0f);

    imu::Quaternion currentQ_;
    int windowWidth_;
    int windowHeight_;

    /// Singleton pointer for GLUT static callbacks.
    static IMUVisualizer* instance_;
};

} // namespace viz

#endif // IMU_VISUALIZER_H
