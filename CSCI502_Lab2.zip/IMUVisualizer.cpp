/**
 * @file IMUVisualizer.cpp
 * @brief OpenGL-based 3D quaternion visualization implementation.
 *
 * Based on the provided cube_quat.cpp, refactored into an OOP class.
 * Uses FreeGLUT for windowing and legacy OpenGL for rendering.
 */

#include "IMUVisualizer.h"

#include <GL/glut.h>
#include <cmath>
#include <iostream>

namespace viz {

// Singleton instance for GLUT callbacks
IMUVisualizer* IMUVisualizer::instance_ = nullptr;

IMUVisualizer::IMUVisualizer()
    : currentQ_{1.0f, 0.0f, 0.0f, 0.0f},
      windowWidth_(900), windowHeight_(600)
{
    instance_ = this;
}

void IMUVisualizer::init(int& argc, char** argv,
                          int width, int height, const char* title)
{
    windowWidth_ = width;
    windowHeight_ = height;

    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
    glutInitWindowSize(width, height);
    glutCreateWindow(title);

    glEnable(GL_DEPTH_TEST);
    glClearColor(0.08f, 0.08f, 0.10f, 1.0f);

    glutDisplayFunc(displayCallback);
    glutReshapeFunc(reshapeCallback);
    glutKeyboardFunc(keyboardCallback);
    glutIdleFunc(idleCallback);

    std::cout << "[IMUVisualizer] Window initialized: "
              << width << "x" << height << "\n";
}

void IMUVisualizer::setQuaternion(const imu::Quaternion& q) {
    currentQ_ = q;
}

imu::Quaternion IMUVisualizer::getQuaternion() const {
    return currentQ_;
}

void IMUVisualizer::requestRedraw() {
    glutPostRedisplay();
}

void IMUVisualizer::run() {
    glutMainLoop();
}

// ---------- Static GLUT Callbacks ----------

void IMUVisualizer::displayCallback() {
    if (instance_) instance_->display();
}

void IMUVisualizer::reshapeCallback(int w, int h) {
    if (instance_) instance_->reshape(w, h);
}

void IMUVisualizer::keyboardCallback(unsigned char key, int, int) {
    if (key == 27 || key == 'q') { // ESC or 'q'
        std::exit(0);
    }
}

void IMUVisualizer::idleCallback() {
    if (instance_) {
        glutPostRedisplay(); // Continuously redraw for real-time updates
    }
}

// ---------- Rendering ----------

void IMUVisualizer::display() {
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

    // Camera
    gluLookAt(0, 0, 3.0,   // eye
              0, 0, 0,     // center
              0, 1, 0);    // up

    // Draw fixed world axes
    drawAxes(1.2f);

    // Apply quaternion rotation to the cube
    auto M = quatToMatrix(currentQ_);
    glPushMatrix();
    glMultMatrixf(M.data());

    // Draw body-frame axes (shorter, rotate with cube)
    drawAxes(0.9f);

    // Draw solid cube with depth offset to prevent z-fighting
    glEnable(GL_POLYGON_OFFSET_FILL);
    glPolygonOffset(1.0f, 1.0f);
    drawCubeSolid(1.0f);
    glDisable(GL_POLYGON_OFFSET_FILL);

    // Draw wireframe on top
    drawCubeWire(1.01f);
    glPopMatrix();

    glutSwapBuffers();
}

void IMUVisualizer::reshape(int w, int h) {
    windowWidth_ = w;
    windowHeight_ = h;
    glViewport(0, 0, w, h);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(60.0, (h > 0) ? (double)w / (double)h : 1.0, 0.1, 100.0);
    glMatrixMode(GL_MODELVIEW);
}

std::array<float, 16> IMUVisualizer::quatToMatrix(const imu::Quaternion& q) {
    // Normalize
    float n = std::sqrt(q.w*q.w + q.x*q.x + q.y*q.y + q.z*q.z);
    float w = q.w/n, x = q.x/n, y = q.y/n, z = q.z/n;

    float xx = x*x, yy = y*y, zz = z*z;
    float xy = x*y, xz = x*z, yz = y*z;
    float wx = w*x, wy = w*y, wz = w*z;

    // Column-major for OpenGL
    std::array<float, 16> m{};
    m[0]  = 1.0f - 2.0f*(yy + zz);
    m[1]  = 2.0f*(xy + wz);
    m[2]  = 2.0f*(xz - wy);
    m[3]  = 0.0f;

    m[4]  = 2.0f*(xy - wz);
    m[5]  = 1.0f - 2.0f*(xx + zz);
    m[6]  = 2.0f*(yz + wx);
    m[7]  = 0.0f;

    m[8]  = 2.0f*(xz + wy);
    m[9]  = 2.0f*(yz - wx);
    m[10] = 1.0f - 2.0f*(xx + yy);
    m[11] = 0.0f;

    m[12] = 0.0f;
    m[13] = 0.0f;
    m[14] = 0.0f;
    m[15] = 1.0f;
    return m;
}

void IMUVisualizer::drawAxes(float length) {
    glLineWidth(2.0f);
    glBegin(GL_LINES);
    // X axis (red)
    glColor3f(1, 0, 0); glVertex3f(0, 0, 0); glVertex3f(length, 0, 0);
    // Y axis (green)
    glColor3f(0, 1, 0); glVertex3f(0, 0, 0); glVertex3f(0, length, 0);
    // Z axis (blue)
    glColor3f(0, 0, 1); glVertex3f(0, 0, 0); glVertex3f(0, 0, length);
    glEnd();
}

void IMUVisualizer::drawCubeWire(float size) {
    glColor3f(1.0f, 1.0f, 1.0f);
    glutWireCube(size);
}

void IMUVisualizer::drawCubeSolid(float size) {
    glColor3f(0.7f, 0.7f, 0.9f);
    glutSolidCube(size);
}

} // namespace viz
