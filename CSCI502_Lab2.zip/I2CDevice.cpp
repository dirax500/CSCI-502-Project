/**
 * @file I2CDevice.cpp
 * @brief Implementation of the I2C Hardware Abstraction Layer.
 *
 * Uses Linux I2C-dev ioctl interface to communicate with I2C slave devices.
 */

#include "I2CDevice.h"

#include <fcntl.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <linux/i2c-dev.h>

#include <iostream>
#include <sstream>
#include <cstring>

namespace hal {

I2CDevice::I2CDevice(unsigned int bus, uint8_t address)
    : bus_(bus), address_(address), fd_(-1)
{
    std::ostringstream oss;
    oss << "/dev/i2c-" << bus;
    devicePath_ = oss.str();
}

I2CDevice::~I2CDevice() {
    close();
}

int I2CDevice::open() {
    fd_ = ::open(devicePath_.c_str(), O_RDWR);
    if (fd_ < 0) {
        std::cerr << "[I2CDevice] Failed to open " << devicePath_
                  << ": " << strerror(errno) << std::endl;
        return -1;
    }
    if (ioctl(fd_, I2C_SLAVE, address_) < 0) {
        std::cerr << "[I2CDevice] Failed to set slave address 0x"
                  << std::hex << (int)address_ << std::dec
                  << ": " << strerror(errno) << std::endl;
        ::close(fd_);
        fd_ = -1;
        return -1;
    }
    return 0;
}

void I2CDevice::close() {
    if (fd_ >= 0) {
        ::close(fd_);
        fd_ = -1;
    }
}

uint8_t I2CDevice::readRegister(uint8_t reg) const {
    uint8_t buf[1] = { reg };
    if (::write(fd_, buf, 1) != 1) {
        std::cerr << "[I2CDevice] Write register address failed\n";
        return 0;
    }
    if (::read(fd_, buf, 1) != 1) {
        std::cerr << "[I2CDevice] Read register failed\n";
        return 0;
    }
    return buf[0];
}

int I2CDevice::writeRegister(uint8_t reg, uint8_t value) const {
    uint8_t buf[2] = { reg, value };
    if (::write(fd_, buf, 2) != 2) {
        std::cerr << "[I2CDevice] Write register failed\n";
        return -1;
    }
    return 0;
}

int I2CDevice::readRegisters(uint8_t startReg, uint8_t* buffer, unsigned int count) const {
    uint8_t reg = startReg;
    if (::write(fd_, &reg, 1) != 1) {
        std::cerr << "[I2CDevice] Write start register failed\n";
        return -1;
    }
    if (::read(fd_, buffer, count) != (int)count) {
        std::cerr << "[I2CDevice] Block read failed\n";
        return -1;
    }
    return 0;
}

int16_t I2CDevice::readRegister16LE(uint8_t regLow) const {
    uint8_t buf[2];
    if (readRegisters(regLow, buf, 2) < 0) return 0;
    return (int16_t)((buf[1] << 8) | buf[0]);
}

} // namespace hal
