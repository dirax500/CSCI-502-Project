# CSCI502/702 Project 2: IMU Sensor Data Processing and 3D Visualization

## Overview
Real-time IMU orientation estimation and 3D visualization system for Raspberry Pi.
Reads 9-axis sensor data (accel + gyro + magnetometer) via I2C, fuses it with the
Madgwick AHRS filter, and renders orientation as a 3D cube using OpenGL.

## Hardware
- Raspberry Pi (I2C bus 1)
- Pololu MinIMU-9 v5 (or compatible):
  - **LSM6DS33** (accel + gyro) @ `0x6B`
  - **LIS3MDL** (magnetometer) @ `0x1E`

## Architecture
```
I2C Bus → I2CDevice (HAL) → Sensor Drivers → Madgwick Filter → Quaternion → OpenGL Cube
```

## Build & Run

```bash
# Install dependencies
sudo apt install -y g++ freeglut3-dev mesa-utils i2c-tools

# Build
make

# Run
./imu_viewer
```

## Controls
- **q / ESC**: Quit

## File Structure
```
include/         # Headers
  I2CDevice.h   # I2C HAL
  IMUSensor.h   # Abstract sensor interface
  LSM6DS33.h    # Accel + Gyro driver
  LIS3MDL.h     # Magnetometer driver
  MadgwickFilter.h  # AHRS filter
  IMUVisualizer.h   # OpenGL viz
src/             # Implementations
  *.cpp
Makefile
uml_class_diagram.mermaid
```

## Team
| Name | Contribution |
|------|-------------|
| [Student 1] | I2C HAL, sensor drivers |
| [Student 2] | Madgwick filter |
| [Student 3] | OpenGL visualization |
| [Student 4] | UML, testing, report |
