/**
 * @file LSM6DS33.cpp
 * @brief Implementation for LSM6DS33 accelerometer + gyroscope driver.
 *
 * Scaling factors from the LSM6DS33 datasheet:
 *   Accelerometer:
 *     ±2g  → 0.061 mg/LSB  → raw * 0.000061 = g
 *     ±4g  → 0.122 mg/LSB
 *     ±8g  → 0.244 mg/LSB
 *     ±16g → 0.488 mg/LSB
 *
 *   Gyroscope:
 *     ±245  dps → 8.75  mdps/LSB → raw * 0.00875 = dps
 *     ±500  dps → 17.50 mdps/LSB
 *     ±1000 dps → 35.00 mdps/LSB
 *     ±2000 dps → 70.00 mdps/LSB
 */

#include "LSM6DS33.h"
#include <iostream>

namespace imu {

// ==================== Accelerometer ====================

LSM6DS33_Accel::LSM6DS33_Accel(hal::I2CDevice& device)
    : dev_(device), scale_(0.000061f) // default ±2g
{}

bool LSM6DS33_Accel::init() {
    // Verify WHO_AM_I
    uint8_t id = dev_.readRegister(LSM6DS33_REG::WHO_AM_I);
    if (id != 0x69) {
        std::cerr << "[LSM6DS33_Accel] WHO_AM_I mismatch: 0x"
                  << std::hex << (int)id << std::dec << " (expected 0x69)\n";
        return false;
    }

    // CTRL1_XL: ODR = 104 Hz (0100), FS = ±2g (00), BW = 400 Hz (00)
    // Bits: 0100 00 00 = 0x40
    dev_.writeRegister(LSM6DS33_REG::CTRL1_XL, 0x40);
    scale_ = 0.000061f; // ±2g: 0.061 mg/LSB

    // CTRL3_C: Enable block data update (BDU), auto-increment
    dev_.writeRegister(LSM6DS33_REG::CTRL3_C, 0x44);

    std::cout << "[LSM6DS33_Accel] Initialized: ±2g, 104 Hz\n";
    return true;
}

void LSM6DS33_Accel::readRaw() {
    rawX_ = dev_.readRegister16LE(LSM6DS33_REG::OUTX_L_XL);
    rawY_ = dev_.readRegister16LE(LSM6DS33_REG::OUTY_L_XL);
    rawZ_ = dev_.readRegister16LE(LSM6DS33_REG::OUTZ_L_XL);
}

Vector3 LSM6DS33_Accel::getScaled() const {
    return {
        rawX_ * scale_,
        rawY_ * scale_,
        rawZ_ * scale_
    };
}

Vector3 LSM6DS33_Accel::getRaw() const {
    return {
        static_cast<float>(rawX_),
        static_cast<float>(rawY_),
        static_cast<float>(rawZ_)
    };
}

void LSM6DS33_Accel::setRange(int g) {
    uint8_t ctrl = dev_.readRegister(LSM6DS33_REG::CTRL1_XL);
    ctrl &= 0xF3; // clear FS bits [3:2]
    switch (g) {
        case 2:  ctrl |= 0x00; scale_ = 0.000061f; break;
        case 4:  ctrl |= 0x08; scale_ = 0.000122f; break;
        case 8:  ctrl |= 0x0C; scale_ = 0.000244f; break;
        case 16: ctrl |= 0x04; scale_ = 0.000488f; break;
        default:
            std::cerr << "[LSM6DS33_Accel] Invalid range: " << g << "g\n";
            return;
    }
    dev_.writeRegister(LSM6DS33_REG::CTRL1_XL, ctrl);
    std::cout << "[LSM6DS33_Accel] Range set to ±" << g << "g\n";
}

// ==================== Gyroscope ====================

LSM6DS33_Gyro::LSM6DS33_Gyro(hal::I2CDevice& device)
    : dev_(device), scale_(0.00875f) // default ±245 dps
{}

bool LSM6DS33_Gyro::init() {
    uint8_t id = dev_.readRegister(LSM6DS33_REG::WHO_AM_I);
    if (id != 0x69) {
        std::cerr << "[LSM6DS33_Gyro] WHO_AM_I mismatch: 0x"
                  << std::hex << (int)id << std::dec << " (expected 0x69)\n";
        return false;
    }

    // CTRL2_G: ODR = 104 Hz (0100), FS = 245 dps (00)
    // Bits: 0100 00 0 0 = 0x40
    dev_.writeRegister(LSM6DS33_REG::CTRL2_G, 0x40);
    scale_ = 0.00875f; // ±245 dps: 8.75 mdps/LSB

    std::cout << "[LSM6DS33_Gyro] Initialized: ±245 dps, 104 Hz\n";
    return true;
}

void LSM6DS33_Gyro::readRaw() {
    rawX_ = dev_.readRegister16LE(LSM6DS33_REG::OUTX_L_G);
    rawY_ = dev_.readRegister16LE(LSM6DS33_REG::OUTY_L_G);
    rawZ_ = dev_.readRegister16LE(LSM6DS33_REG::OUTZ_L_G);
}

Vector3 LSM6DS33_Gyro::getScaled() const {
    // Return degrees per second
    return {
        rawX_ * scale_,
        rawY_ * scale_,
        rawZ_ * scale_
    };
}

Vector3 LSM6DS33_Gyro::getRaw() const {
    return {
        static_cast<float>(rawX_),
        static_cast<float>(rawY_),
        static_cast<float>(rawZ_)
    };
}

void LSM6DS33_Gyro::setRange(int dps) {
    uint8_t ctrl = dev_.readRegister(LSM6DS33_REG::CTRL2_G);
    ctrl &= 0xF3; // clear FS bits [3:2]
    switch (dps) {
        case 245:  ctrl |= 0x00; scale_ = 0.00875f;  break;
        case 500:  ctrl |= 0x04; scale_ = 0.01750f;  break;
        case 1000: ctrl |= 0x08; scale_ = 0.03500f;  break;
        case 2000: ctrl |= 0x0C; scale_ = 0.07000f;  break;
        default:
            std::cerr << "[LSM6DS33_Gyro] Invalid range: " << dps << " dps\n";
            return;
    }
    dev_.writeRegister(LSM6DS33_REG::CTRL2_G, ctrl);
    std::cout << "[LSM6DS33_Gyro] Range set to ±" << dps << " dps\n";
}

} // namespace imu
