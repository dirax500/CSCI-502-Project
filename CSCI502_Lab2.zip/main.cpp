/**
 * @file main.cpp
 * @brief Main application: IMU data acquisition, AHRS fusion, and 3D visualization.
 *
 * This program:
 *   1. Opens I2C devices for the LSM6DS33 (accel+gyro) and LIS3MDL (magnetometer)
 *   2. Configures sensor registers via the Hardware Abstraction Layer
 *   3. Reads sensor data in a timer loop at ~100 Hz
 *   4. Feeds data through the Madgwick AHRS filter to compute orientation quaternion
 *   5. Visualizes the orientation in real-time using OpenGL (3D cube)
 *
 * Hardware:
 *   - Raspberry Pi (I2C bus 1)
 *   - Pololu MinIMU-9 v5 (or compatible):
 *       LSM6DS33 (accel + gyro) at I2C address 0x6B
 *       LIS3MDL  (magnetometer) at I2C address 0x1E
 *
 * Build:
 *   g++ -std=c++17 -O2 -Iinclude src/*.cpp -lglut -lGL -lGLU -o imu_viewer
 *
 * Run:
 *   ./imu_viewer
 */

#include "I2CDevice.h"
#include "LSM6DS33.h"
#include "LIS3MDL.h"
#include "MadgwickFilter.h"
#include "IMUVisualizer.h"

#include <GL/glut.h>
#include <iostream>
#include <iomanip>
#include <cmath>
#include <chrono>

// ======== Global objects ========
// I2C devices (bus 1 on Raspberry Pi)
static hal::I2CDevice g_lsm6Device(1, 0x6B);  // Accel + Gyro
static hal::I2CDevice g_lis3Device(1, 0x1E);   // Magnetometer

// Sensor drivers
static imu::LSM6DS33_Accel g_accel(g_lsm6Device);
static imu::LSM6DS33_Gyro  g_gyro(g_lsm6Device);
static imu::LIS3MDL_Mag    g_mag(g_lis3Device);

// AHRS filter (100 Hz sample rate, beta = 0.1)
static imu::MadgwickFilter g_filter(100.0f, 0.1f);

// Visualizer
static viz::IMUVisualizer g_viz;

// Timing
static const int SAMPLE_PERIOD_MS = 10; // 100 Hz

// Degrees to radians conversion factor
static constexpr float DEG2RAD = M_PI / 180.0f;

/**
 * @brief GLUT timer callback: reads sensors, updates filter, updates display.
 *
 * This function is called every SAMPLE_PERIOD_MS milliseconds by GLUT.
 * It forms the real-time data pipeline:
 *   Sensors → Scaling → Madgwick Filter → Quaternion → Visualizer
 */
static void timerCallback(int) {
    // 1. Read raw sensor data
    g_accel.readRaw();
    g_gyro.readRaw();
    g_mag.readRaw();

    // 2. Get scaled values in physical units
    imu::Vector3 acc  = g_accel.getScaled();  // in g
    imu::Vector3 gyro = g_gyro.getScaled();   // in dps (degrees per second)
    imu::Vector3 mag  = g_mag.getScaled();    // in gauss

    // 3. Convert gyroscope from degrees/s to radians/s (Madgwick requires rad/s)
    float gx = gyro.x * DEG2RAD;
    float gy = gyro.y * DEG2RAD;
    float gz = gyro.z * DEG2RAD;

    // 4. Run Madgwick AHRS filter update (9-axis fusion)
    g_filter.update(gx, gy, gz,
                    acc.x, acc.y, acc.z,
                    mag.x, mag.y, mag.z);

    // 5. Get orientation quaternion and update the visualizer
    imu::Quaternion q = g_filter.getQuaternion();
    g_viz.setQuaternion(q);

    // 6. Print quaternion to terminal
    std::cout << std::fixed << std::setprecision(4)
              << "q = [w=" << q.w
              << " x=" << q.x
              << " y=" << q.y
              << " z=" << q.z << "]\r" << std::flush;

    // 7. Request display update
    g_viz.requestRedraw();

    // 8. Re-register timer for next iteration
    glutTimerFunc(SAMPLE_PERIOD_MS, timerCallback, 0);
}

int main(int argc, char** argv) {
    std::cout << "============================================\n";
    std::cout << "  IMU Sensor Data Processing & 3D Viewer\n";
    std::cout << "  CSCI502 - HW/SW Co-Design Project 2\n";
    std::cout << "============================================\n\n";

    // ---- Step 1: Open I2C buses ----
    std::cout << "[Main] Opening I2C devices...\n";

    if (g_lsm6Device.open() < 0) {
        std::cerr << "[Main] Failed to open LSM6DS33 at 0x6B\n";
        return 1;
    }
    if (g_lis3Device.open() < 0) {
        std::cerr << "[Main] Failed to open LIS3MDL at 0x1E\n";
        return 1;
    }

    // ---- Step 2: Initialize sensors ----
    std::cout << "[Main] Initializing sensors...\n";

    if (!g_accel.init()) {
        std::cerr << "[Main] Accelerometer init failed!\n";
        return 1;
    }
    if (!g_gyro.init()) {
        std::cerr << "[Main] Gyroscope init failed!\n";
        return 1;
    }
    if (!g_mag.init()) {
        std::cerr << "[Main] Magnetometer init failed!\n";
        return 1;
    }

    std::cout << "\n[Main] All sensors initialized successfully.\n";
    std::cout << "[Main] Starting real-time visualization...\n";
    std::cout << "[Main] Press 'q' or ESC in the OpenGL window to quit.\n\n";

    // ---- Step 3: Initialize OpenGL visualizer ----
    g_viz.init(argc, argv, 900, 600, "IMU 3D Orientation - CSCI502 Project 2");

    // ---- Step 4: Start the sensor reading timer ----
    glutTimerFunc(SAMPLE_PERIOD_MS, timerCallback, 0);

    // ---- Step 5: Enter GLUT main loop (blocking) ----
    g_viz.run();

    return 0;
}
