#ifndef MADGWICK_FILTER_H
#define MADGWICK_FILTER_H

/**
 * @file MadgwickFilter.h
 * @brief Madgwick AHRS (Attitude and Heading Reference System) filter.
 *
 * Implements Sebastian Madgwick's gradient-descent-based orientation filter
 * for fusing accelerometer, gyroscope, and magnetometer data into a
 * quaternion-based orientation estimate.
 *
 * Reference:
 *   S. O. H. Madgwick, "An efficient orientation filter for inertial and
 *   inertial/magnetic sensor arrays", Report x-io, University of Bristol, 2010.
 *   http://www.x-io.co.uk/open-source-imu-and-ahrs-algorithms/
 *
 * Input requirements (physical units):
 *   - Gyroscope: radians per second (rad/s)
 *   - Accelerometer: any unit (normalized internally)
 *   - Magnetometer: any unit (normalized internally)
 */

namespace imu {

/// Quaternion representation: [w, x, y, z]
struct Quaternion {
    float w{1.0f}, x{0.0f}, y{0.0f}, z{0.0f};
};

class MadgwickFilter {
public:
    /**
     * @param sampleFreq  Sensor sampling frequency in Hz (e.g., 100)
     * @param beta        Filter gain (default 0.1; higher = faster convergence,
     *                    more noise; lower = smoother, slower response)
     */
    MadgwickFilter(float sampleFreq = 100.0f, float beta = 0.1f);

    /**
     * @brief Update with 9-axis data (accel + gyro + mag).
     *
     * @param gx, gy, gz  Gyroscope in rad/s
     * @param ax, ay, az  Accelerometer (any consistent unit, normalized internally)
     * @param mx, my, mz  Magnetometer (any consistent unit, normalized internally)
     */
    void update(float gx, float gy, float gz,
                float ax, float ay, float az,
                float mx, float my, float mz);

    /**
     * @brief Update with 6-axis data (accel + gyro only, no magnetometer).
     *
     * @param gx, gy, gz  Gyroscope in rad/s
     * @param ax, ay, az  Accelerometer (normalized internally)
     */
    void updateIMU(float gx, float gy, float gz,
                   float ax, float ay, float az);

    /// Get the current orientation quaternion estimate.
    Quaternion getQuaternion() const { return q_; }

    /// Reset filter to identity orientation.
    void reset();

    /// Set/get parameters
    void setSampleFreq(float freq) { sampleFreq_ = freq; }
    void setBeta(float beta) { beta_ = beta; }
    float getSampleFreq() const { return sampleFreq_; }
    float getBeta() const { return beta_; }

private:
    float sampleFreq_;
    float beta_;
    Quaternion q_;

    /// Fast inverse square root (Quake III algorithm).
    static float invSqrt(float x);
};

} // namespace imu

#endif // MADGWICK_FILTER_H
