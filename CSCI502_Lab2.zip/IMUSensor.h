#ifndef IMU_SENSOR_H
#define IMU_SENSOR_H

/**
 * @file IMUSensor.h
 * @brief Abstract interface for IMU sensor components.
 *
 * Defines the contract that all IMU sensor drivers must implement.
 * Application code programs against this interface, not concrete hardware.
 */

#include <cstdint>

namespace imu {

/// 3-axis measurement vector
struct Vector3 {
    float x{0.0f}, y{0.0f}, z{0.0f};
};

/**
 * @brief Abstract base class for any 3-axis IMU sensor (gyro, accel, mag).
 */
class IMUSensor {
public:
    virtual ~IMUSensor() = default;

    /// Initialize sensor registers and power on.
    virtual bool init() = 0;

    /// Read raw sensor data into internal buffers.
    virtual void readRaw() = 0;

    /// Get the most recent calibrated measurement in physical units.
    /// Gyroscope: degrees per second (dps)
    /// Accelerometer: g (9.81 m/s^2 per g)
    /// Magnetometer: gauss
    virtual Vector3 getScaled() const = 0;

    /// Get raw (unscaled) values.
    virtual Vector3 getRaw() const = 0;
};

} // namespace imu

#endif // IMU_SENSOR_H
