#ifndef I2C_DEVICE_H
#define I2C_DEVICE_H

/**
 * @file I2CDevice.h
 * @brief Hardware Abstraction Layer for I2C communication on Raspberry Pi.
 *
 * This class encapsulates all low-level Linux I2C ioctl calls, providing
 * a clean C++ interface for reading/writing registers on I2C slave devices.
 * Application code should use this class (or subclasses) instead of
 * directly accessing /dev/i2c-*.
 */

#include <cstdint>
#include <string>

namespace hal {

class I2CDevice {
public:
    /**
     * @brief Construct an I2CDevice for a given bus and slave address.
     * @param bus     I2C bus number (e.g. 1 for /dev/i2c-1)
     * @param address 7-bit I2C slave address
     */
    I2CDevice(unsigned int bus, uint8_t address);

    /// Destructor closes the file descriptor.
    virtual ~I2CDevice();

    // Prevent copying (owns a file descriptor)
    I2CDevice(const I2CDevice&) = delete;
    I2CDevice& operator=(const I2CDevice&) = delete;

    /// Open the I2C bus. Returns 0 on success, -1 on failure.
    int open();

    /// Close the I2C bus.
    void close();

    /// Check if the device file descriptor is open.
    bool isOpen() const { return fd_ >= 0; }

    /// Read a single byte from a register.
    uint8_t readRegister(uint8_t reg) const;

    /// Write a single byte to a register.
    int writeRegister(uint8_t reg, uint8_t value) const;

    /// Read a block of bytes starting at a given register.
    int readRegisters(uint8_t startReg, uint8_t* buffer, unsigned int count) const;

    /// Read a 16-bit value (little-endian: low register first).
    int16_t readRegister16LE(uint8_t regLow) const;

    /// Getters
    unsigned int getBus() const { return bus_; }
    uint8_t getAddress() const { return address_; }

protected:
    unsigned int bus_;
    uint8_t address_;
    int fd_;                     ///< Linux file descriptor for /dev/i2c-N
    std::string devicePath_;     ///< e.g. "/dev/i2c-1"
};

} // namespace hal

#endif // I2C_DEVICE_H
