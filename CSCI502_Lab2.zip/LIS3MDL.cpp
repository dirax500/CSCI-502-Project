/**
 * @file LIS3MDL.cpp
 * @brief Implementation for LIS3MDL magnetometer driver.
 *
 * Scaling factors from the LIS3MDL datasheet:
 *   ±4  gauss → 6842 LSB/gauss → 1/6842 = 0.0001461 gauss/LSB
 *   ±8  gauss → 3421 LSB/gauss → 1/3421 = 0.0002923 gauss/LSB
 *   ±12 gauss → 2281 LSB/gauss → 1/2281 = 0.0004384 gauss/LSB
 *   ±16 gauss → 1711 LSB/gauss → 1/1711 = 0.0005846 gauss/LSB
 */

#include "LIS3MDL.h"
#include <iostream>

namespace imu {

LIS3MDL_Mag::LIS3MDL_Mag(hal::I2CDevice& device)
    : dev_(device), scale_(1.0f / 6842.0f) // default ±4 gauss
{}

bool LIS3MDL_Mag::init() {
    // Verify WHO_AM_I
    uint8_t id = dev_.readRegister(LIS3MDL_REG::WHO_AM_I);
    if (id != 0x3D) {
        std::cerr << "[LIS3MDL_Mag] WHO_AM_I mismatch: 0x"
                  << std::hex << (int)id << std::dec << " (expected 0x3D)\n";
        return false;
    }

    // CTRL_REG1: Temperature sensor enabled, high-performance mode (XY), ODR = 10 Hz
    // Bits: 0 11 0100 0 = 0x70
    dev_.writeRegister(LIS3MDL_REG::CTRL_REG1, 0x70);

    // CTRL_REG2: Full-scale = ±4 gauss (00)
    // Bits: 0 00 00000 = 0x00
    dev_.writeRegister(LIS3MDL_REG::CTRL_REG2, 0x00);
    scale_ = 1.0f / 6842.0f;

    // CTRL_REG3: Continuous-conversion mode
    dev_.writeRegister(LIS3MDL_REG::CTRL_REG3, 0x00);

    // CTRL_REG4: Z-axis high-performance mode
    dev_.writeRegister(LIS3MDL_REG::CTRL_REG4, 0x0C);

    // CTRL_REG5: Block data update enabled
    dev_.writeRegister(LIS3MDL_REG::CTRL_REG5, 0x40);

    std::cout << "[LIS3MDL_Mag] Initialized: ±4 gauss, 10 Hz, high-perf\n";
    return true;
}

void LIS3MDL_Mag::readRaw() {
    rawX_ = dev_.readRegister16LE(LIS3MDL_REG::OUT_X_L);
    rawY_ = dev_.readRegister16LE(LIS3MDL_REG::OUT_Y_L);
    rawZ_ = dev_.readRegister16LE(LIS3MDL_REG::OUT_Z_L);
}

Vector3 LIS3MDL_Mag::getScaled() const {
    return {
        rawX_ * scale_,
        rawY_ * scale_,
        rawZ_ * scale_
    };
}

Vector3 LIS3MDL_Mag::getRaw() const {
    return {
        static_cast<float>(rawX_),
        static_cast<float>(rawY_),
        static_cast<float>(rawZ_)
    };
}

void LIS3MDL_Mag::setRange(int gauss) {
    uint8_t ctrl2 = 0x00;
    switch (gauss) {
        case 4:  ctrl2 = 0x00; scale_ = 1.0f / 6842.0f; break;
        case 8:  ctrl2 = 0x20; scale_ = 1.0f / 3421.0f; break;
        case 12: ctrl2 = 0x40; scale_ = 1.0f / 2281.0f; break;
        case 16: ctrl2 = 0x60; scale_ = 1.0f / 1711.0f; break;
        default:
            std::cerr << "[LIS3MDL_Mag] Invalid range: " << gauss << " gauss\n";
            return;
    }
    dev_.writeRegister(LIS3MDL_REG::CTRL_REG2, ctrl2);
    std::cout << "[LIS3MDL_Mag] Range set to ±" << gauss << " gauss\n";
}

} // namespace imu
