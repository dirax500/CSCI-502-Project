#ifndef LSM6DS33_H
#define LSM6DS33_H

/**
 * @file LSM6DS33.h
 * @brief Driver for the LSM6DS33 3D accelerometer and 3D gyroscope.
 *
 * I2C address: 0x6B (SA0 high) or 0x6A (SA0 low).
 * The LSM6DS33 contains both a 3-axis accelerometer and a 3-axis gyroscope
 * in a single package. This driver configures both sensors and reads
 * their data through the I2C HAL.
 *
 * Datasheet: ST LSM6DS33
 */

#include "I2CDevice.h"
#include "IMUSensor.h"

namespace imu {

// ---------- LSM6DS33 Register Map (selected) ----------
namespace LSM6DS33_REG {
    constexpr uint8_t WHO_AM_I    = 0x0F;  // Expected: 0x69
    constexpr uint8_t CTRL1_XL    = 0x10;  // Accelerometer control
    constexpr uint8_t CTRL2_G     = 0x11;  // Gyroscope control
    constexpr uint8_t CTRL3_C     = 0x12;  // Control register 3
    constexpr uint8_t STATUS_REG  = 0x1E;

    // Gyroscope output registers (little-endian pairs)
    constexpr uint8_t OUTX_L_G   = 0x22;
    constexpr uint8_t OUTX_H_G   = 0x23;
    constexpr uint8_t OUTY_L_G   = 0x24;
    constexpr uint8_t OUTY_H_G   = 0x25;
    constexpr uint8_t OUTZ_L_G   = 0x26;
    constexpr uint8_t OUTZ_H_G   = 0x27;

    // Accelerometer output registers (little-endian pairs)
    constexpr uint8_t OUTX_L_XL  = 0x28;
    constexpr uint8_t OUTX_H_XL  = 0x29;
    constexpr uint8_t OUTY_L_XL  = 0x2A;
    constexpr uint8_t OUTY_H_XL  = 0x2B;
    constexpr uint8_t OUTZ_L_XL  = 0x2C;
    constexpr uint8_t OUTZ_H_XL  = 0x2D;
}

/**
 * @brief Accelerometer component of LSM6DS33.
 */
class LSM6DS33_Accel : public IMUSensor {
public:
    /**
     * @param device Shared pointer to the underlying I2C device.
     *               The device must already be opened.
     */
    explicit LSM6DS33_Accel(hal::I2CDevice& device);
    ~LSM6DS33_Accel() override = default;

    bool init() override;
    void readRaw() override;
    Vector3 getScaled() const override;
    Vector3 getRaw() const override;

    /// Set full-scale range: 2, 4, 8, or 16 g. Default: 2g.
    void setRange(int g);

private:
    hal::I2CDevice& dev_;
    int16_t rawX_{0}, rawY_{0}, rawZ_{0};
    float scale_;   ///< Conversion factor: raw → g
};

/**
 * @brief Gyroscope component of LSM6DS33.
 */
class LSM6DS33_Gyro : public IMUSensor {
public:
    explicit LSM6DS33_Gyro(hal::I2CDevice& device);
    ~LSM6DS33_Gyro() override = default;

    bool init() override;
    void readRaw() override;
    Vector3 getScaled() const override;
    Vector3 getRaw() const override;

    /// Set full-scale range: 245, 500, 1000, or 2000 dps. Default: 245 dps.
    void setRange(int dps);

private:
    hal::I2CDevice& dev_;
    int16_t rawX_{0}, rawY_{0}, rawZ_{0};
    float scale_;   ///< Conversion factor: raw → dps
};

} // namespace imu

#endif // LSM6DS33_H
