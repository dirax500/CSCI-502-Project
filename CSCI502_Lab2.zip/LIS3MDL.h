#ifndef LIS3MDL_H
#define LIS3MDL_H

/**
 * @file LIS3MDL.h
 * @brief Driver for the LIS3MDL 3-axis magnetometer.
 *
 * I2C address: 0x1E (SA1 high) or 0x1C (SA1 low).
 * Full-scale ranges: ±4, ±8, ±12, ±16 gauss.
 *
 * Datasheet: ST LIS3MDL
 */

#include "I2CDevice.h"
#include "IMUSensor.h"

namespace imu {

namespace LIS3MDL_REG {
    constexpr uint8_t WHO_AM_I    = 0x0F;  // Expected: 0x3D
    constexpr uint8_t CTRL_REG1   = 0x20;
    constexpr uint8_t CTRL_REG2   = 0x21;
    constexpr uint8_t CTRL_REG3   = 0x22;
    constexpr uint8_t CTRL_REG4   = 0x23;
    constexpr uint8_t CTRL_REG5   = 0x24;
    constexpr uint8_t STATUS_REG  = 0x27;

    // Magnetometer output registers (little-endian pairs)
    constexpr uint8_t OUT_X_L     = 0x28;
    constexpr uint8_t OUT_X_H     = 0x29;
    constexpr uint8_t OUT_Y_L     = 0x2A;
    constexpr uint8_t OUT_Y_H     = 0x2B;
    constexpr uint8_t OUT_Z_L     = 0x2C;
    constexpr uint8_t OUT_Z_H     = 0x2D;
}

/**
 * @brief LIS3MDL magnetometer driver implementing the IMUSensor interface.
 */
class LIS3MDL_Mag : public IMUSensor {
public:
    explicit LIS3MDL_Mag(hal::I2CDevice& device);
    ~LIS3MDL_Mag() override = default;

    bool init() override;
    void readRaw() override;
    Vector3 getScaled() const override;
    Vector3 getRaw() const override;

    /// Set full-scale range: 4, 8, 12, or 16 gauss. Default: 4 gauss.
    void setRange(int gauss);

private:
    hal::I2CDevice& dev_;
    int16_t rawX_{0}, rawY_{0}, rawZ_{0};
    float scale_;   ///< Conversion factor: raw → gauss
};

} // namespace imu

#endif // LIS3MDL_H
